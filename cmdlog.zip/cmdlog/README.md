# CmdLog (Fabric 1.21.11)

Serwer zapisuje wszystkie komendy graczy. Admin w grze wpisuje `/cmdlog`, w menu podaje nick + date i widzi liste komend z tego dnia.

## Budowanie
Najprosciej: pobierz oficjalny szablon z https://fabricmc.net/develop/template (MC 1.21.11, Yarn),
usun z niego `src/`, wstaw tu folder `src/` z tego projektu, a `gradle.properties` / `build.gradle`
zostaw z szablonu (sprawdz tylko, czy wersje sie zgadzaja).

Albo uzyj plikow z tego zipa i wygeneruj wrapper: `gradle wrapper --gradle-version 9.2.1`, potem:

    ./gradlew build

Gotowy plik: `build/libs/cmdlog-1.0.0.jar` (bez `-sources`).

## Instalacja
- Wrzuc jar do `mods/` **serwera** i do `mods/` **klienta** admina (wymagany Fabric API).
- Uruchom serwer raz - powstanie `cmdlog/admins.txt` (w folderze glownym serwera).
- Wpisz tam swoj nick (jeden na linie). Uprawnienia sprawdza serwer.

## Uzycie
- W grze: `/cmdlog` -> menu. Wpisz nick, data (domyslnie dzis, format RRRR-MM-DD) -> Szukaj.
- Scroll myszka przewija liste (pokazuje do 500 ostatnich komend z dnia).
- Logi: `cmdlog/logs/RRRR-MM-DD.log` (tekst: godzina, UUID, nick, komenda).

## Uwagi
- Loguje tylko komendy od momentu instalacji moda.
- Komendy wpisane w singleplayerze tez sie loguja (zintegrowany serwer) - dodaj swoj nick do admins.txt.
