package pl.cmdlog.client;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import pl.cmdlog.ResultPayload;

public class CmdLogClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ResultPayload.ID, (payload, context) -> {
            if (context.client().currentScreen instanceof CmdLogScreen screen) {
                screen.onResult(payload);
            }
        });

        // /cmdlog w czacie otwiera menu
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("cmdlog").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new CmdLogScreen()));
                    return Command.SINGLE_SUCCESS;
                })));
    }
}
