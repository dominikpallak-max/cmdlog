package pl.cmdlog.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import pl.cmdlog.QueryPayload;
import pl.cmdlog.ResultPayload;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class CmdLogScreen extends Screen {
    private static final int LINE_H = 11;
    private static final int TOP = 62;

    private TextFieldWidget nickField;
    private TextFieldWidget dateField;

    private String lastNick = "";
    private String lastDate = LocalDate.now().toString();
    private String status = "Wpisz nick i date, potem kliknij Szukaj.";
    private int statusColor = 0xFFAAAAAA;
    private List<String> lines = List.of();
    private int scroll = 0;

    public CmdLogScreen() {
        super(Text.literal("CmdLog - komendy gracza"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        nickField = new TextFieldWidget(this.textRenderer, cx - 150, 32, 130, 20, Text.literal("Nick"));
        nickField.setMaxLength(16);
        nickField.setPlaceholder(Text.literal("Nick gracza"));
        nickField.setText(lastNick);

        dateField = new TextFieldWidget(this.textRenderer, cx - 12, 32, 90, 20, Text.literal("Data"));
        dateField.setMaxLength(10);
        dateField.setText(lastDate);

        addDrawableChild(nickField);
        addDrawableChild(dateField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Szukaj"), b -> search())
                .dimensions(cx + 84, 32, 66, 20).build());

        setInitialFocus(nickField);
    }

    private void search() {
        lastNick = nickField.getText().trim();
        lastDate = dateField.getText().trim();

        if (lastNick.isEmpty()) {
            setStatus("Wpisz nick gracza.", 0xFFFF5555);
            return;
        }
        try {
            LocalDate.parse(lastDate);
        } catch (DateTimeParseException e) {
            setStatus("Zly format daty - uzyj RRRR-MM-DD.", 0xFFFF5555);
            return;
        }

        setStatus("Szukam...", 0xFFAAAAAA);
        ClientPlayNetworking.send(new QueryPayload(lastNick, lastDate));
    }

    public void onResult(ResultPayload p) {
        if (!p.error().isEmpty()) {
            lines = List.of();
            setStatus(p.error(), 0xFFFF5555);
            return;
        }
        lines = p.lines();
        scroll = 0;
        if (lines.isEmpty()) {
            setStatus("Brak komend gracza " + p.nick() + " z dnia " + p.date() + ".", 0xFFFFFF55);
        } else {
            setStatus(p.nick() + " - " + p.date() + ": " + lines.size() + " komend(y)", 0xFF55FF55);
        }
    }

    private void setStatus(String text, int color) {
        this.status = text;
        this.statusColor = color;
    }

    private int visibleLines() {
        return Math.max(1, (this.height - 10 - TOP) / LINE_H);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, lines.size() - visibleLines());
        scroll -= (int) Math.signum(verticalAmount) * 3;
        scroll = Math.max(0, Math.min(scroll, max));
        return true;
    }

    @Override
    public boolean shouldPause() {
        // Bez tego w singleplayerze serwer by sie zatrzymal i nie odpowiedzial.
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int cx = this.width / 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 12, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(status), cx - 150, 54 - 1, statusColor);

        int left = cx - 150;
        int right = cx + 150;
        int bottom = this.height - 8;
        ctx.fill(left - 4, TOP - 3, right + 4, bottom + 2, 0xA0000000);

        int visible = visibleLines();
        int max = Math.max(0, lines.size() - visible);
        scroll = Math.max(0, Math.min(scroll, max));

        int y = TOP;
        for (int i = scroll; i < Math.min(lines.size(), scroll + visible); i++) {
            String trimmed = this.textRenderer.trimToWidth(lines.get(i), right - left);
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(trimmed), left, y, 0xFFFFFFFF);
            y += LINE_H;
        }

        if (lines.size() > visible) {
            ctx.drawTextWithShadow(this.textRenderer,
                    Text.literal((scroll + 1) + "-" + Math.min(lines.size(), scroll + visible) + " / " + lines.size()),
                    right - 70, 54 - 1, 0xFFAAAAAA);
        }
    }
}
